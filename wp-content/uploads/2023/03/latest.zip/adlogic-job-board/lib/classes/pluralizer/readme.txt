Unzip downloaded file (pluralizer.zip)

Upload folder "pluralizer" in your server.

(You may upload the files wherever else you like, but make sure that all files stay in
the same directory)
 
Type:  http://www.(yourdomain).com/pluralizer/pluralize.html  in your browser

Have fan.

 