<?php get_header(); ?>
<h1>Use a WP Template file for the home page!</h1>
<?php get_footer(); ?>